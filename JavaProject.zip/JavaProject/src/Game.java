public class Game {

	public static void main(String[] args) {
		
		Stockage jeux = new Stockage();
		jeux.question();

	}
	
}
